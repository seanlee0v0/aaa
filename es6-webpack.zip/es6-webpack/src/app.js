import header from './module/header';
document.body.innerHTML = header;
