export default `
  <header>
    <h1>My first es6-webpack!</h1>
  </header>
`
